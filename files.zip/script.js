// Get the parts of the page we need to work with
const form = document.getElementById("task-form");
const input = document.getElementById("task-input");
const list = document.getElementById("task-list");
const count = document.getElementById("count");
const empty = document.getElementById("empty");

// Load saved tasks from the browser, or start with an empty list
let tasks = [];
try {
  tasks = JSON.parse(localStorage.getItem("tasks")) || [];
} catch (error) {
  tasks = [];
}

// Save the tasks so they stay after you refresh the page
function save() {
  try {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  } catch (error) {
    // If saving is not allowed, the app still works without saving
  }
}

// Draw the whole list on the page
function render() {
  list.innerHTML = "";

  tasks.forEach(function (task, index) {
    const li = document.createElement("li");
    if (task.done) li.classList.add("done");

    const text = document.createElement("span");
    text.textContent = task.text;
    // Clicking the text marks the task as done or not done
    text.addEventListener("click", function () {
      tasks[index].done = !tasks[index].done;
      save();
      render();
    });

    const del = document.createElement("button");
    del.className = "delete";
    del.textContent = "Delete";
    del.setAttribute("aria-label", "Delete task: " + task.text);
    // Clicking Delete removes the task
    del.addEventListener("click", function () {
      tasks.splice(index, 1);
      save();
      render();
    });

    li.appendChild(text);
    li.appendChild(del);
    list.appendChild(li);
  });

  const left = tasks.filter(function (task) { return !task.done; }).length;
  count.textContent = left + (left === 1 ? " task left" : " tasks left");
  empty.style.display = tasks.length === 0 ? "block" : "none";
}

// When the form is submitted, add a new task
form.addEventListener("submit", function (event) {
  event.preventDefault(); // stop the page from reloading
  const value = input.value.trim();
  if (value === "") return;

  tasks.push({ text: value, done: false });
  input.value = "";
  save();
  render();
});

render();
